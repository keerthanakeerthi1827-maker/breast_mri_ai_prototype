"""
Educational prototype for breast MRI image review.
IMPORTANT: This demo does NOT diagnose cancer and does NOT contain trained medical models.
It only demonstrates an image-upload workflow and clearly labels the output as a placeholder.
"""
from flask import Flask, render_template, request
from PIL import Image
import io
import base64

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024  # 8 MB upload limit
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg"}

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/", methods=["GET", "POST"])
def index():
    image_data = None
    message = None
    if request.method == "POST":
        file = request.files.get("mri_image")
        if not file or file.filename == "":
            message = "Please choose an image file."
        elif not allowed_file(file.filename):
            message = "For this demo, upload a PNG or JPG image."
        else:
            try:
                raw = file.read()
                image = Image.open(io.BytesIO(raw)).convert("RGB")
                image.thumbnail((700, 500))
                buffer = io.BytesIO()
                image.save(buffer, format="JPEG")
                image_data = base64.b64encode(buffer.getvalue()).decode("utf-8")
                message = (
                    "Demo upload successful. No tumour detection or subtype prediction was performed. "
                    "A trained and clinically validated model is required for medical analysis."
                )
            except Exception:
                message = "The file could not be read as an image. Please try a PNG or JPG."
    return render_template("index.html", image_data=image_data, message=message)

if __name__ == "__main__":
    app.run(debug=True)
