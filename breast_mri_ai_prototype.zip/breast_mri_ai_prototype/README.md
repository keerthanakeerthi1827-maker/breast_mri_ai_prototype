# Breast MRI AI — Educational Prototype

A student-friendly Flask website demonstrating image upload and preview for a breast MRI AI project.

## Important limitations
This repository is **not a medical diagnostic system**. It does not run Faster R-CNN or a 3D CNN, and it does not predict tumour presence or cancer subtype. The output is a placeholder explaining that no medical analysis occurred. Do not use it for clinical decisions or upload real patient information.

## Current features
- Upload PNG/JPG sample images (8 MB maximum).
- Preview the selected image.
- Display a clear notice that medical inference is not implemented.

## Technology
- Python 3
- Flask
- Pillow
- HTML/CSS

## Setup
1. Install Python 3.10 or later.
2. Open a terminal in this folder.
3. Create a virtual environment (recommended):
   - Windows: `py -m venv .venv`
   - Windows PowerShell: `.venv\Scripts\Activate.ps1`
   - macOS/Linux: `python3 -m venv .venv`
   - macOS/Linux activation: `source .venv/bin/activate`
4. Install dependencies:
   `pip install -r requirements.txt`
5. Start the local development server:
   `python app.py`
6. Open `http://127.0.0.1:5000` in your browser.

## Project structure
```text
breast_mri_ai_prototype/
├── app.py
├── requirements.txt
├── README.md
├── LICENSE
├── .gitignore
├── templates/
│   └── index.html
└── static/
    └── style.css
```

## Planned architecture (not yet implemented)
MRI data with suitable permissions → preprocessing → Faster R-CNN tumour localization → 3D CNN subtype classification → evaluation and clinician review.

The model pipeline requires a legally accessible, appropriately annotated dataset, patient-level train/validation/test splits, training code, and independent clinical evaluation. Do not claim model accuracy until measured on a held-out dataset.

## Basic manual test cases
1. Open the home page: the upload form and research-only warning should appear.
2. Submit with no file selected: browser validation should request a file.
3. Upload a valid PNG/JPG under 8 MB: image preview and placeholder message should appear.
4. Upload a text/PDF file: the app should reject it.
5. Upload a file larger than 8 MB: Flask should reject the request.

## Data and privacy
No sample medical images are included. Use only non-identifiable images that you have permission to use. Never commit identifiable patient data, credentials, or private medical records.

## License
Released under the MIT License; see `LICENSE`.
